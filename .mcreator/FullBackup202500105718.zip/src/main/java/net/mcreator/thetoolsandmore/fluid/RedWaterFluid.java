
package net.mcreator.thetoolsandmore.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModItems;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModFluids;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModFluidTypes;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModBlocks;

public abstract class RedWaterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TheToolsAndMoreModFluidTypes.RED_WATER_TYPE.get(), () -> TheToolsAndMoreModFluids.RED_WATER.get(),
			() -> TheToolsAndMoreModFluids.FLOWING_RED_WATER.get()).explosionResistance(100f).bucket(() -> TheToolsAndMoreModItems.RED_WATER_BUCKET.get()).block(() -> (LiquidBlock) TheToolsAndMoreModBlocks.RED_WATER.get());

	private RedWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends RedWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RedWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
