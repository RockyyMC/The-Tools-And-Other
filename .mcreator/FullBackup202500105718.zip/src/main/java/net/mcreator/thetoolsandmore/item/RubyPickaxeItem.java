
package net.mcreator.thetoolsandmore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RubyPickaxeItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 5000, 9f, 0, 15, TagKey.create(Registries.ITEM, ResourceLocation.parse("the_tools_and_more:ruby_pickaxe_repair_items")));

	public RubyPickaxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 4f, -2f, properties);
	}
}
