
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thetoolsandmore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.thetoolsandmore.TheToolsAndMoreMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TheToolsAndMoreModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TheToolsAndMoreMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ARMADURAS = REGISTRY.register("armaduras",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.armaduras")).icon(() -> new ItemStack(TheToolsAndMoreModItems.AMETHYST_ARMOR_CHESTPLATE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.COPPER_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.COPPER_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.COPPER_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.COPPER_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.STONE_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.STONE_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.STONE_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.STONE_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_ARMOR_BOOTS.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_ARMOR_HELMET.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_ARMOR_CHESTPLATE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_ARMOR_LEGGINGS.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_ARMOR_BOOTS.get());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> HERRAMIENTAS = REGISTRY.register("herramientas",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.herramientas")).icon(() -> new ItemStack(TheToolsAndMoreModItems.AMETHYST_PICKAXE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.AMETHYST_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.CHERRY_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONEE_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONEE_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONEE_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONEE_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONEE_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERT_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERT_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERT_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERT_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERT_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.BERNY_DIMENCION.get());
				tabData.accept(TheToolsAndMoreModItems.DIAMOND_HAMMER.get());
				tabData.accept(TheToolsAndMoreModItems.LAPIS_LAZULI_HAMMER.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_HAMMER.get());
				tabData.accept(TheToolsAndMoreModItems.IRON_HAMMER.get());
				tabData.accept(TheToolsAndMoreModItems.NETHERITE_HAMMER.get());
				tabData.accept(TheToolsAndMoreModItems.STICK.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.RUBBY_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.OBSIDIAN_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.MAGNE_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_HOE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_PICKAXE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_AXE.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_SWORD.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_SHOVEL.get());
				tabData.accept(TheToolsAndMoreModItems.AQUA_DARK_HOE.get());
			}).withTabsBefore(ARMADURAS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> INGOT = REGISTRY.register("ingot",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.ingot")).icon(() -> new ItemStack(TheToolsAndMoreModItems.RUBY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModItems.RUBY.get());
				tabData.accept(TheToolsAndMoreModItems.BLUE_RUBY_INGOT.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONE_INGOT.get());
				tabData.accept(TheToolsAndMoreModItems.REDSTONENUGGET.get());
				tabData.accept(TheToolsAndMoreModItems.COPPERNUGGET.get());
				tabData.accept(TheToolsAndMoreModItems.RUBY_INGOT.get());
			}).withTabsBefore(HERRAMIENTAS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BLOQUES = REGISTRY.register("bloques",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.bloques")).icon(() -> new ItemStack(TheToolsAndMoreModBlocks.RUBY_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModBlocks.RUBY_ORE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.RUBY_BLOCK.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BLUERUBYORE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.RED_REINFORCED_BRICKS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_WOOD.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_LOG.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_PLANKS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_STAIRS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_SLAB.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_FENCE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_FENCE_GATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_PRESSURE_PLATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_BUTTON.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNIFICTECIOSS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNIFICTECIOSS_REINFORCED.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_LOG.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_PLANKS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_WOOD.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_DOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_TRAPDOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_FENCE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_FENCE_GATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_PRESSURE_PLATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.MAGNE_BUTTOM.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_LOG.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_PLANKS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_WOOD.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_TRAPDOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_PRESSURE_PLATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_BUTTOM.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_LOG.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_PLANKS.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_WOOD.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_DOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_TRAPDOOR.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_PRESSURE_PLATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_BUTTOM.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_FENCE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.AQUA_DARK_FENCE_GATE.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.GREEN_OAK_LOG.get().asItem());
				tabData.accept(TheToolsAndMoreModBlocks.GREEN_OAK_PLANKS.get().asItem());
			}).withTabsBefore(INGOT.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FLUIDS = REGISTRY.register("fluids",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.fluids")).icon(() -> new ItemStack(TheToolsAndMoreModItems.GREEN_WATER_BUCKET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModItems.GREEN_WATER_BUCKET.get());
				tabData.accept(TheToolsAndMoreModItems.RED_WATER_BUCKET.get());
			}).withTabsBefore(BLOQUES.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> NATURALS = REGISTRY.register("naturals",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.the_tools_and_more.naturals")).icon(() -> new ItemStack(TheToolsAndMoreModBlocks.BERNY_LEAVES.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheToolsAndMoreModBlocks.BERNY_LEAVES.get().asItem());
				tabData.accept(TheToolsAndMoreModItems.BANANA.get());
				tabData.accept(TheToolsAndMoreModBlocks.BANANA_FRUIT.get().asItem());
			}).withTabsBefore(FLUIDS.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(TheToolsAndMoreModItems.RUBY_ARMOR_HELMET.get());
			tabData.accept(TheToolsAndMoreModItems.RUBY_ARMOR_CHESTPLATE.get());
			tabData.accept(TheToolsAndMoreModItems.RUBY_ARMOR_LEGGINGS.get());
			tabData.accept(TheToolsAndMoreModItems.RUBY_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(TheToolsAndMoreModBlocks.BLUE_RUBY_BLOCK.get().asItem());
		}
	}
}
