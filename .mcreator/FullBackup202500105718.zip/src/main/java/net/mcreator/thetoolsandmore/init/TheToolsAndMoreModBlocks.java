
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thetoolsandmore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.thetoolsandmore.block.RubyOreBlock;
import net.mcreator.thetoolsandmore.block.RubyBlockBlock;
import net.mcreator.thetoolsandmore.block.RedWaterBlock;
import net.mcreator.thetoolsandmore.block.RedReinforcedBricksBlock;
import net.mcreator.thetoolsandmore.block.MagnificteciossReinforcedBlock;
import net.mcreator.thetoolsandmore.block.MagnificteciossBlock;
import net.mcreator.thetoolsandmore.block.MagneWoodBlock;
import net.mcreator.thetoolsandmore.block.MagneTrapdoorBlock;
import net.mcreator.thetoolsandmore.block.MagnePressurePlateBlock;
import net.mcreator.thetoolsandmore.block.MagnePlanksBlock;
import net.mcreator.thetoolsandmore.block.MagneLogBlock;
import net.mcreator.thetoolsandmore.block.MagneFenceGateBlock;
import net.mcreator.thetoolsandmore.block.MagneFenceBlock;
import net.mcreator.thetoolsandmore.block.MagneDoorBlock;
import net.mcreator.thetoolsandmore.block.MagneButtomBlock;
import net.mcreator.thetoolsandmore.block.GreenWaterBlock;
import net.mcreator.thetoolsandmore.block.GreenOakPlanksBlock;
import net.mcreator.thetoolsandmore.block.GreenOakLogBlock;
import net.mcreator.thetoolsandmore.block.BluerubyoreBlock;
import net.mcreator.thetoolsandmore.block.Blue_RubyBlockBlock;
import net.mcreator.thetoolsandmore.block.BernyWoodBlock;
import net.mcreator.thetoolsandmore.block.BernyStairsBlock;
import net.mcreator.thetoolsandmore.block.BernySlabBlock;
import net.mcreator.thetoolsandmore.block.BernyPressurePlateBlock;
import net.mcreator.thetoolsandmore.block.BernyPlanksBlock;
import net.mcreator.thetoolsandmore.block.BernyLogBlock;
import net.mcreator.thetoolsandmore.block.BernyLeavesBlock;
import net.mcreator.thetoolsandmore.block.BernyFenceGateBlock;
import net.mcreator.thetoolsandmore.block.BernyFenceBlock;
import net.mcreator.thetoolsandmore.block.BernyDimencionPortalBlock;
import net.mcreator.thetoolsandmore.block.BernyButtonBlock;
import net.mcreator.thetoolsandmore.block.BananaFruitBlock;
import net.mcreator.thetoolsandmore.block.AquaWoodBlock;
import net.mcreator.thetoolsandmore.block.AquaTrapdoorBlock;
import net.mcreator.thetoolsandmore.block.AquaPressurePlateBlock;
import net.mcreator.thetoolsandmore.block.AquaPlanksBlock;
import net.mcreator.thetoolsandmore.block.AquaLogBlock;
import net.mcreator.thetoolsandmore.block.AquaDoorBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkWoodBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkTrapdoorBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkPressurePlateBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkPlanksBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkLogBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkFenceGateBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkFenceBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkDoorBlock;
import net.mcreator.thetoolsandmore.block.AquaDarkButtomBlock;
import net.mcreator.thetoolsandmore.block.AquaButtomBlock;
import net.mcreator.thetoolsandmore.TheToolsAndMoreMod;

import java.util.function.Function;

public class TheToolsAndMoreModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(TheToolsAndMoreMod.MODID);
	public static final DeferredBlock<Block> RUBY_ORE = register("ruby_ore", RubyOreBlock::new);
	public static final DeferredBlock<Block> RUBY_BLOCK = register("ruby_block", RubyBlockBlock::new);
	public static final DeferredBlock<Block> BLUE_RUBY_BLOCK = register("blue_ruby_block", Blue_RubyBlockBlock::new);
	public static final DeferredBlock<Block> BLUERUBYORE = register("bluerubyore", BluerubyoreBlock::new);
	public static final DeferredBlock<Block> GREEN_WATER = register("green_water", GreenWaterBlock::new);
	public static final DeferredBlock<Block> RED_WATER = register("red_water", RedWaterBlock::new);
	public static final DeferredBlock<Block> RED_REINFORCED_BRICKS = register("red_reinforced_bricks", RedReinforcedBricksBlock::new);
	public static final DeferredBlock<Block> BERNY_WOOD = register("berny_wood", BernyWoodBlock::new);
	public static final DeferredBlock<Block> BERNY_LOG = register("berny_log", BernyLogBlock::new);
	public static final DeferredBlock<Block> BERNY_PLANKS = register("berny_planks", BernyPlanksBlock::new);
	public static final DeferredBlock<Block> BERNY_LEAVES = register("berny_leaves", BernyLeavesBlock::new);
	public static final DeferredBlock<Block> BERNY_STAIRS = register("berny_stairs", BernyStairsBlock::new);
	public static final DeferredBlock<Block> BERNY_SLAB = register("berny_slab", BernySlabBlock::new);
	public static final DeferredBlock<Block> BERNY_FENCE = register("berny_fence", BernyFenceBlock::new);
	public static final DeferredBlock<Block> BERNY_FENCE_GATE = register("berny_fence_gate", BernyFenceGateBlock::new);
	public static final DeferredBlock<Block> BERNY_PRESSURE_PLATE = register("berny_pressure_plate", BernyPressurePlateBlock::new);
	public static final DeferredBlock<Block> BERNY_BUTTON = register("berny_button", BernyButtonBlock::new);
	public static final DeferredBlock<Block> MAGNIFICTECIOSS = register("magnifictecioss", MagnificteciossBlock::new);
	public static final DeferredBlock<Block> MAGNIFICTECIOSS_REINFORCED = register("magnifictecioss_reinforced", MagnificteciossReinforcedBlock::new);
	public static final DeferredBlock<Block> BANANA_FRUIT = register("banana_fruit", BananaFruitBlock::new);
	public static final DeferredBlock<Block> BERNY_DIMENCION_PORTAL = register("berny_dimencion_portal", BernyDimencionPortalBlock::new);
	public static final DeferredBlock<Block> MAGNE_LOG = register("magne_log", MagneLogBlock::new);
	public static final DeferredBlock<Block> MAGNE_PLANKS = register("magne_planks", MagnePlanksBlock::new);
	public static final DeferredBlock<Block> MAGNE_WOOD = register("magne_wood", MagneWoodBlock::new);
	public static final DeferredBlock<Block> MAGNE_DOOR = register("magne_door", MagneDoorBlock::new);
	public static final DeferredBlock<Block> MAGNE_TRAPDOOR = register("magne_trapdoor", MagneTrapdoorBlock::new);
	public static final DeferredBlock<Block> MAGNE_FENCE = register("magne_fence", MagneFenceBlock::new);
	public static final DeferredBlock<Block> MAGNE_FENCE_GATE = register("magne_fence_gate", MagneFenceGateBlock::new);
	public static final DeferredBlock<Block> MAGNE_PRESSURE_PLATE = register("magne_pressure_plate", MagnePressurePlateBlock::new);
	public static final DeferredBlock<Block> MAGNE_BUTTOM = register("magne_buttom", MagneButtomBlock::new);
	public static final DeferredBlock<Block> AQUA_LOG = register("aqua_log", AquaLogBlock::new);
	public static final DeferredBlock<Block> AQUA_PLANKS = register("aqua_planks", AquaPlanksBlock::new);
	public static final DeferredBlock<Block> AQUA_WOOD = register("aqua_wood", AquaWoodBlock::new);
	public static final DeferredBlock<Block> AQUA_DOOR = register("aqua_door", AquaDoorBlock::new);
	public static final DeferredBlock<Block> AQUA_TRAPDOOR = register("aqua_trapdoor", AquaTrapdoorBlock::new);
	public static final DeferredBlock<Block> AQUA_PRESSURE_PLATE = register("aqua_pressure_plate", AquaPressurePlateBlock::new);
	public static final DeferredBlock<Block> AQUA_BUTTOM = register("aqua_buttom", AquaButtomBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_LOG = register("aqua_dark_log", AquaDarkLogBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_PLANKS = register("aqua_dark_planks", AquaDarkPlanksBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_WOOD = register("aqua_dark_wood", AquaDarkWoodBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_DOOR = register("aqua_dark_door", AquaDarkDoorBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_TRAPDOOR = register("aqua_dark_trapdoor", AquaDarkTrapdoorBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_PRESSURE_PLATE = register("aqua_dark_pressure_plate", AquaDarkPressurePlateBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_BUTTOM = register("aqua_dark_buttom", AquaDarkButtomBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_FENCE = register("aqua_dark_fence", AquaDarkFenceBlock::new);
	public static final DeferredBlock<Block> AQUA_DARK_FENCE_GATE = register("aqua_dark_fence_gate", AquaDarkFenceGateBlock::new);
	public static final DeferredBlock<Block> GREEN_OAK_LOG = register("green_oak_log", GreenOakLogBlock::new);
	public static final DeferredBlock<Block> GREEN_OAK_PLANKS = register("green_oak_planks", GreenOakPlanksBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
