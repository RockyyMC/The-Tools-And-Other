
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thetoolsandmore.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.thetoolsandmore.client.model.Modelmetist;
import net.mcreator.thetoolsandmore.client.model.Modelblack_swamp_boat_v2;
import net.mcreator.thetoolsandmore.client.model.ModelRockyDweller;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class TheToolsAndMoreModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelblack_swamp_boat_v2.LAYER_LOCATION, Modelblack_swamp_boat_v2::createBodyLayer);
		event.registerLayerDefinition(ModelRockyDweller.LAYER_LOCATION, ModelRockyDweller::createBodyLayer);
		event.registerLayerDefinition(Modelmetist.LAYER_LOCATION, Modelmetist::createBodyLayer);
	}
}
