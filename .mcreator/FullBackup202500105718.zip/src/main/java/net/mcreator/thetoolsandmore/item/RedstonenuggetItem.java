
package net.mcreator.thetoolsandmore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RedstonenuggetItem extends Item {
	public RedstonenuggetItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64));
	}
}
