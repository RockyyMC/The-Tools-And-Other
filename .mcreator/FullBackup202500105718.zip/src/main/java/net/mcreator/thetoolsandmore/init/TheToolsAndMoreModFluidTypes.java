
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thetoolsandmore.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.thetoolsandmore.fluid.types.RedWaterFluidType;
import net.mcreator.thetoolsandmore.fluid.types.GreenWaterFluidType;
import net.mcreator.thetoolsandmore.TheToolsAndMoreMod;

public class TheToolsAndMoreModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, TheToolsAndMoreMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> GREEN_WATER_TYPE = REGISTRY.register("green_water", () -> new GreenWaterFluidType());
	public static final DeferredHolder<FluidType, FluidType> RED_WATER_TYPE = REGISTRY.register("red_water", () -> new RedWaterFluidType());
}
