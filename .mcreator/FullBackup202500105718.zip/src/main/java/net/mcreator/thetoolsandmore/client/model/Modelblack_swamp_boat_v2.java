package net.mcreator.thetoolsandmore.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 4.12.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelblack_swamp_boat_v2 extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("the_tools_and_more", "modelblack_swamp_boat_v_2"), "main");
	public final ModelPart Helice;
	public final ModelPart c1;
	public final ModelPart izq2;
	public final ModelPart Izq;
	public final ModelPart dere2;
	public final ModelPart derecha;
	public final ModelPart c2;
	public final ModelPart dere4;
	public final ModelPart izq4;
	public final ModelPart Izq3;
	public final ModelPart derecha3;
	public final ModelPart c3;
	public final ModelPart izq5;
	public final ModelPart Izq4;
	public final ModelPart dere5;
	public final ModelPart derecha4;
	public final ModelPart c4;
	public final ModelPart dere3;
	public final ModelPart Izq2;
	public final ModelPart izq3;
	public final ModelPart derecha2;
	public final ModelPart Jaula;
	public final ModelPart barrera;
	public final ModelPart techo;
	public final ModelPart Motor;
	public final ModelPart Volante;
	public final ModelPart Panel;
	public final ModelPart bone3;
	public final ModelPart Base;
	public final ModelPart Aciento;
	public final ModelPart Respaldar;
	public final ModelPart Baradal;
	public final ModelPart bone9;
	public final ModelPart bone4;
	public final ModelPart bone6;
	public final ModelPart bone5;
	public final ModelPart bone7;
	public final ModelPart Paredes;
	public final ModelPart bone2;
	public final ModelPart bone;
	public final ModelPart Vidrio;
	public final ModelPart bone12;
	public final ModelPart bone11;
	public final ModelPart bone13;
	public final ModelPart bone14;
	public final ModelPart bone10;
	public final ModelPart Punta;
	public final ModelPart bone18;
	public final ModelPart bone15;
	public final ModelPart bone16;
	public final ModelPart bone17;
	public final ModelPart Flotador;
	public final ModelPart bone21;
	public final ModelPart bone29;
	public final ModelPart bone20;
	public final ModelPart bone26;
	public final ModelPart bone23;
	public final ModelPart bone28;
	public final ModelPart bone25;
	public final ModelPart bone27;
	public final ModelPart bone22;
	public final ModelPart bone24;
	public final ModelPart bone19;
	public final ModelPart Atrasyesquina;
	public final ModelPart bone30;

	public Modelblack_swamp_boat_v2(ModelPart root) {
		super(root);
		this.Helice = root.getChild("Helice");
		this.c1 = this.Helice.getChild("c1");
		this.izq2 = this.c1.getChild("izq2");
		this.Izq = this.c1.getChild("Izq");
		this.dere2 = this.Izq.getChild("dere2");
		this.derecha = this.c1.getChild("derecha");
		this.c2 = this.Helice.getChild("c2");
		this.dere4 = this.c2.getChild("dere4");
		this.izq4 = this.c2.getChild("izq4");
		this.Izq3 = this.c2.getChild("Izq3");
		this.derecha3 = this.c2.getChild("derecha3");
		this.c3 = this.Helice.getChild("c3");
		this.izq5 = this.c3.getChild("izq5");
		this.Izq4 = this.c3.getChild("Izq4");
		this.dere5 = this.c3.getChild("dere5");
		this.derecha4 = this.c3.getChild("derecha4");
		this.c4 = this.Helice.getChild("c4");
		this.dere3 = this.c4.getChild("dere3");
		this.Izq2 = this.c4.getChild("Izq2");
		this.izq3 = this.c4.getChild("izq3");
		this.derecha2 = this.c4.getChild("derecha2");
		this.Jaula = root.getChild("Jaula");
		this.barrera = this.Jaula.getChild("barrera");
		this.techo = this.Jaula.getChild("techo");
		this.Motor = root.getChild("Motor");
		this.Volante = root.getChild("Volante");
		this.Panel = root.getChild("Panel");
		this.bone3 = this.Panel.getChild("bone3");
		this.Base = root.getChild("Base");
		this.Aciento = root.getChild("Aciento");
		this.Respaldar = this.Aciento.getChild("Respaldar");
		this.Baradal = root.getChild("Baradal");
		this.bone9 = this.Baradal.getChild("bone9");
		this.bone4 = this.Baradal.getChild("bone4");
		this.bone6 = this.Baradal.getChild("bone6");
		this.bone5 = this.Baradal.getChild("bone5");
		this.bone7 = this.Baradal.getChild("bone7");
		this.Paredes = root.getChild("Paredes");
		this.bone2 = this.Paredes.getChild("bone2");
		this.bone = this.Paredes.getChild("bone");
		this.Vidrio = root.getChild("Vidrio");
		this.bone12 = this.Vidrio.getChild("bone12");
		this.bone11 = this.Vidrio.getChild("bone11");
		this.bone13 = this.Vidrio.getChild("bone13");
		this.bone14 = this.Vidrio.getChild("bone14");
		this.bone10 = this.Vidrio.getChild("bone10");
		this.Punta = root.getChild("Punta");
		this.bone18 = this.Punta.getChild("bone18");
		this.bone15 = this.Punta.getChild("bone15");
		this.bone16 = this.Punta.getChild("bone16");
		this.bone17 = this.Punta.getChild("bone17");
		this.Flotador = root.getChild("Flotador");
		this.bone21 = this.Flotador.getChild("bone21");
		this.bone29 = this.Flotador.getChild("bone29");
		this.bone20 = this.Flotador.getChild("bone20");
		this.bone26 = this.bone20.getChild("bone26");
		this.bone23 = this.Flotador.getChild("bone23");
		this.bone28 = this.Flotador.getChild("bone28");
		this.bone25 = this.Flotador.getChild("bone25");
		this.bone27 = this.Flotador.getChild("bone27");
		this.bone22 = this.Flotador.getChild("bone22");
		this.bone24 = this.Flotador.getChild("bone24");
		this.bone19 = this.Flotador.getChild("bone19");
		this.Atrasyesquina = this.Flotador.getChild("Atrasyesquina");
		this.bone30 = this.Flotador.getChild("bone30");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition Helice = partdefinition.addOrReplaceChild("Helice", CubeListBuilder.create(), PartPose.offsetAndRotation(-34.0F, -3.0F, -54.0F, 0.0F, 0.0F, 1.5708F));
		PartDefinition c1 = Helice.addOrReplaceChild("c1", CubeListBuilder.create().texOffs(6, 40).addBox(11.0F, -17.9857F, 52.5F, 4.0F, -12.6F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40)
				.addBox(12.0F, -18.0857F, 52.5F, 2.0F, 5.2F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40).addBox(12.0F, -35.9857F, 52.5F, 2.0F, 5.4F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-8.0F, -10.0143F, 24.5F));
		PartDefinition izq2 = c1.addOrReplaceChild("izq2", CubeListBuilder.create().texOffs(6, 40).addBox(-10.0164F, -50.0354F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(13.2F, 15.0143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition Izq = c1.addOrReplaceChild("Izq", CubeListBuilder.create().texOffs(6, 40).addBox(9.0315F, -49.9614F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(12.8F, 15.0143F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition dere2 = Izq.addOrReplaceChild("dere2", CubeListBuilder.create().texOffs(6, 40).addBox(-19.013F, -18.8161F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(23.0392F, -14.3521F, 0.0F));
		PartDefinition derecha = c1.addOrReplaceChild("derecha", CubeListBuilder.create().texOffs(6, 40).addBox(2.8261F, -30.1555F, 77.0F, 1.0F, 5.5757F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 10.6143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition c2 = Helice
				.addOrReplaceChild(
						"c2", CubeListBuilder.create().texOffs(6, 40).addBox(21.5657F, -12.9857F, 52.5F, 4.0F, -12.3983F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40)
								.addBox(22.5657F, -13.9857F, 52.5F, 2.0F, 6.3951F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40).addBox(22.5657F, -30.7836F, 52.5F, 2.0F, 6.531F, 2.0F, new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(2.0F, -4.0143F, 24.5F, 0.0F, 0.0F, -0.7854F));
		PartDefinition dere4 = c2.addOrReplaceChild("dere4", CubeListBuilder.create().texOffs(6, 40).addBox(-9.5273F, -11.7667F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(33.0108F, -3.1561F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition izq4 = c2.addOrReplaceChild("izq4", CubeListBuilder.create().texOffs(6, 40).addBox(1.2921F, -46.7474F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(13.2F, 15.0143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition Izq3 = c2.addOrReplaceChild("Izq3", CubeListBuilder.create().texOffs(6, 40).addBox(18.5334F, -43.0039F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(12.8F, 15.0143F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition derecha3 = c2.addOrReplaceChild("derecha3", CubeListBuilder.create().texOffs(6, 40).addBox(14.1507F, -26.7755F, 77.0F, 1.0F, 5.5757F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 10.6143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition c3 = Helice.addOrReplaceChild("c3", CubeListBuilder.create().texOffs(6, 40).addBox(6.4336F, -7.6857F, 52.5F, 4.0F, -12.6071F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40)
				.addBox(7.4336F, -8.4029F, 52.5F, 2.0F, 6.0449F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40).addBox(7.5043F, -25.6958F, 52.5F, 2.0F, 6.3222F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-10.5F, -30.3143F, 24.5F, 0.0F, 0.0F, 0.7854F));
		PartDefinition izq5 = c3.addOrReplaceChild("izq5", CubeListBuilder.create().texOffs(6, 40).addBox(-12.7261F, -39.1059F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(13.2F, 15.0143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition Izq4 = c3.addOrReplaceChild("Izq4", CubeListBuilder.create().texOffs(6, 40).addBox(2.7472F, -40.6178F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(12.8F, 15.0143F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition dere5 = c3.addOrReplaceChild("dere5", CubeListBuilder.create().texOffs(6, 40).addBox(-29.5553F, -8.1766F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(36.9706F, -4.8532F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition derecha4 = c3.addOrReplaceChild("derecha4", CubeListBuilder.create().texOffs(6, 40).addBox(0.0998F, -18.9128F, 77.0F, 1.0F, 5.5757F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 10.6143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition c4 = Helice.addOrReplaceChild("c4", CubeListBuilder.create().texOffs(6, 40).addBox(32.0F, -6.3857F, 52.5F, 4.0F, -12.6F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40)
				.addBox(33.0F, -6.3857F, 52.5F, 2.0F, 5.2F, 2.0F, new CubeDeformation(0.0F)).texOffs(6, 40).addBox(33.0F, -23.9857F, 52.5F, 2.0F, 5.4F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(18.0F, -0.0143F, 24.5F, 0.0F, 0.0F, -1.5708F));
		PartDefinition dere3 = c4.addOrReplaceChild("dere3", CubeListBuilder.create().texOffs(6, 40).addBox(-0.2653F, -3.6299F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(32.8392F, -3.0378F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition Izq2 = c4.addOrReplaceChild("Izq2", CubeListBuilder.create().texOffs(6, 40).addBox(27.6287F, -34.4971F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(12.8F, 15.0143F, -24.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition izq3 = c4.addOrReplaceChild("izq3", CubeListBuilder.create().texOffs(6, 40).addBox(12.7484F, -41.8643F, 77.0F, 1.0F, 5.5F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(13.2F, 15.0143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition derecha2 = c4.addOrReplaceChild("derecha2", CubeListBuilder.create().texOffs(6, 40).addBox(25.5387F, -22.2798F, 77.0F, 1.0F, 5.5757F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 10.6143F, -24.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition Jaula = partdefinition.addOrReplaceChild("Jaula",
				CubeListBuilder.create().texOffs(72, 52).addBox(21.0F, -12.0F, -62.0F, 2.0F, 12.0F, -18.0F, new CubeDeformation(0.0F)).texOffs(72, 52).addBox(-6.0F, -12.0F, -62.0F, 2.0F, 12.0F, -18.0F, new CubeDeformation(0.0F)).texOffs(72, 52)
						.addBox(-6.0F, -23.0F, -62.0F, 2.0F, 11.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(72, 52).addBox(-6.0F, -23.0F, -74.0F, 2.0F, 11.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(72, 52)
						.addBox(21.0F, -23.0F, -62.0F, 2.0F, 11.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(72, 52).addBox(21.0F, -23.0F, -74.0F, 2.0F, 11.0F, -2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-8.0F, 16.0F, 90.0F));
		PartDefinition barrera = Jaula.addOrReplaceChild("barrera", CubeListBuilder.create().texOffs(72, 55).addBox(-72.0F, -18.0F, 4.0F, 1.0F, 18.4F, -25.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, -4.0F, 0.0F, -1.5708F, 0.0F));
		PartDefinition techo = Jaula.addOrReplaceChild("techo",
				CubeListBuilder.create().texOffs(72, 52).addBox(-29.0F, -16.0F, -62.0F, 2.0F, 16.0F, -14.0F, new CubeDeformation(0.0F)).texOffs(55, 44).addBox(-27.0F, -2.0F, -62.0F, 2.0F, 6.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(61, 43)
						.addBox(-27.0F, -2.0F, -74.0F, 2.0F, 6.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(46, 49).addBox(-27.0F, -21.0F, -62.0F, 2.0F, 7.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(51, 44)
						.addBox(-27.0F, -21.0F, -74.0F, 2.0F, 7.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(72, 52).addBox(-25.0F, 2.0F, -62.0F, 2.0F, 4.0F, -14.0F, new CubeDeformation(0.0F)).texOffs(72, 52)
						.addBox(-25.0F, -23.0F, -62.0F, 2.0F, 4.0F, -14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5708F));
		PartDefinition Motor = partdefinition.addOrReplaceChild("Motor", CubeListBuilder.create().texOffs(2, 0).addBox(-41.0F, -17.0F, 4.0F, 3.0F, 17.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(2, 0)
				.addBox(-44.0F, -17.0F, 5.0F, 3.0F, 6.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(2, 0).addBox(-49.0F, -16.0F, 6.0F, 5.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, 16.0F, -23.0F, 0.0F, 1.5708F, 0.0F));
		PartDefinition Volante = partdefinition.addOrReplaceChild("Volante",
				CubeListBuilder.create().texOffs(15, 4).addBox(12.6667F, -6.6739F, -9.3283F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(9, 44).addBox(6.6667F, -7.9595F, -7.7962F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(23, 70)
						.addBox(10.6667F, -6.579F, -9.3415F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(96, 46).addBox(3.6667F, -7.8646F, -7.8094F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(88, 42)
						.addBox(5.6667F, -2.9182F, -10.1456F, 1.0F, 1.0F, 5.0316F, new CubeDeformation(0.0F)).texOffs(6, 8).addBox(7.6667F, -2.9182F, -10.1456F, 1.0F, 1.0F, 5.0316F, new CubeDeformation(0.0F)).texOffs(19, 6)
						.addBox(6.1667F, -3.0596F, -10.1355F, 2.4F, 1.0F, 1.0316F, new CubeDeformation(0.0F)).texOffs(80, 46).addBox(6.1667F, -2.9182F, -6.1757F, 2.4F, 1.0F, 1.0316F, new CubeDeformation(0.0F)).texOffs(12, 46)
						.addBox(13.6667F, -6.579F, -9.3415F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(91, 48).addBox(10.6667F, -6.6204F, -12.2481F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(96, 42)
						.addBox(15.6667F, -6.6653F, -11.3277F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(15, 4).addBox(9.6667F, -6.6653F, -11.3277F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(92, 46)
						.addBox(10.6667F, -6.6785F, -6.4226F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(10, 66).addBox(12.6667F, -6.6336F, -8.343F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(8, 47)
						.addBox(12.6667F, -6.6107F, -11.3262F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.6667F, 13.2567F, -4.886F, -0.7854F, 0.0F, 0.0F));
		PartDefinition Panel = partdefinition.addOrReplaceChild("Panel", CubeListBuilder.create().texOffs(26, 37).addBox(0.0F, -6.5183F, -23.638F, 17.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-8.0F, 16.0F, 15.7F));
		PartDefinition bone3 = Panel.addOrReplaceChild("bone3", CubeListBuilder.create().texOffs(30, 36).addBox(3.0F, -13.7722F, 5.1569F, 17.0F, 8.2869F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, 1.7722F, -22.0414F, 0.7854F, 0.0F, 0.0F));
		PartDefinition Base = partdefinition.addOrReplaceChild("Base",
				CubeListBuilder.create().texOffs(46, 53).addBox(-6.0F, 0.0F, 20.0F, 29.0F, 1.0F, -18.0F, new CubeDeformation(0.0F)).texOffs(46, 53).addBox(-4.0F, 0.0F, 2.0F, 25.0F, 1.0F, -6.0F, new CubeDeformation(0.0F)).texOffs(46, 53)
						.addBox(-2.0F, 0.0F, -4.0F, 21.5F, 1.0F, -6.0F, new CubeDeformation(0.0F)).texOffs(46, 53).addBox(-3.0F, 0.0F, -4.0F, 1.5F, 1.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(46, 53)
						.addBox(-1.0F, 0.0F, -10.0F, 18.9F, 1.0F, -6.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-8.0F, 16.0F, 8.0F));
		PartDefinition Aciento = partdefinition.addOrReplaceChild("Aciento",
				CubeListBuilder.create().texOffs(19, 73).addBox(11.0F, -2.1F, 24.9F, 16.0F, 1.0F, -8.0F, new CubeDeformation(0.0F)).texOffs(107, 73).addBox(26.0F, 6.9F, 24.9F, 1.0F, -8.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(87, 74)
						.addBox(26.0F, 6.9F, 18.9F, 1.0F, -8.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(101, 63).addBox(11.0F, 6.9F, 18.9F, 1.0F, -8.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(100, 66)
						.addBox(11.0F, 6.9F, 24.9F, 1.0F, -8.0F, -2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-19.0F, 9.0F, -16.2F));
		PartDefinition Respaldar = Aciento.addOrReplaceChild("Respaldar",
				CubeListBuilder.create().texOffs(4, 66).addBox(8.0F, -21.5714F, 20.6372F, 16.0F, 8.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 66).addBox(10.0F, -23.5714F, 20.6372F, 12.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 66)
						.addBox(9.0F, -22.5714F, 20.6372F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 66).addBox(22.0F, -22.5714F, 20.6372F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, 6.0F, 0.3F, -0.2618F, 0.0F, 0.0F));
		PartDefinition Baradal = partdefinition.addOrReplaceChild("Baradal", CubeListBuilder.create(), PartPose.offset(-8.0F, 16.0F, 8.0F));
		PartDefinition bone9 = Baradal.addOrReplaceChild("bone9", CubeListBuilder.create().texOffs(34, 18).addBox(-26.0745F, 8.0F, 18.3994F, 4.4462F, 1.0F, 2.9585F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-24.7255F, -21.0F, -20.0579F, 0.0F, 1.5708F, 0.0F));
		PartDefinition bone4 = Baradal.addOrReplaceChild("bone4", CubeListBuilder.create().texOffs(126, 25).addBox(20.0132F, -13.0F, 4.0255F, 3.0104F, 1.0F, -24.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.3F, 0.0F, 2.9F, 0.0F, 0.2618F, 0.0F));
		PartDefinition bone6 = Baradal.addOrReplaceChild("bone6", CubeListBuilder.create().texOffs(127, 26).addBox(5.6354F, 8.0F, 48.2235F, 2.8256F, 1.0F, -24.4456F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.6745F, -21.0F, -46.0579F, 0.0F, -0.2618F, 0.0F));
		PartDefinition bone5 = Baradal.addOrReplaceChild("bone5", CubeListBuilder.create().texOffs(95, 19).addBox(-25.0745F, 8.0F, 3.9994F, 3.0462F, 1.0F, -17.6415F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0745F, -21.0F, 2.6421F, 0.0F, -1.5708F, 0.0F));
		PartDefinition bone7 = Baradal.addOrReplaceChild("bone7", CubeListBuilder.create().texOffs(97, 13).addBox(20.2F, -13.0F, 6.0398F, 3.2952F, 1.0623F, -6.0398F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition Paredes = partdefinition.addOrReplaceChild("Paredes", CubeListBuilder.create(), PartPose.offset(-8.0F, 16.0F, -2.0F));
		PartDefinition bone2 = Paredes.addOrReplaceChild("bone2", CubeListBuilder.create().texOffs(73, 55).addBox(-5.166F, -12.1F, 0.2156F, 2.0F, 13.0F, -25.5474F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.0F, 0.0F, 13.0F, 0.0F, -0.2618F, 0.0F));
		PartDefinition bone = Paredes.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(73, 55).addBox(19.7753F, -12.0F, 7.8696F, 2.0F, 13.0F, -25.0485F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.1F, 0.0F, 9.8F, 0.0F, 0.2618F, 0.0F));
		PartDefinition Vidrio = partdefinition.addOrReplaceChild("Vidrio", CubeListBuilder.create(), PartPose.offset(-98.9255F, -5.0F, -39.3579F));
		PartDefinition bone12 = Vidrio.addOrReplaceChild("bone12", CubeListBuilder.create(), PartPose.offsetAndRotation(81.0F, 1.1F, 4.0F, 0.0F, 1.5708F, 0.0F));
		PartDefinition bone11 = Vidrio.addOrReplaceChild("bone11", CubeListBuilder.create(), PartPose.offsetAndRotation(92.0F, 1.0F, 0.0F, 0.0F, -0.2618F, 0.0F));
		PartDefinition bone13 = Vidrio.addOrReplaceChild("bone13", CubeListBuilder.create(), PartPose.offset(78.0F, 1.0F, 0.0F));
		PartDefinition bone14 = Vidrio.addOrReplaceChild("bone14", CubeListBuilder.create(), PartPose.offset(116.0F, 1.0F, 0.0F));
		PartDefinition bone10 = Vidrio.addOrReplaceChild("bone10", CubeListBuilder.create(), PartPose.offsetAndRotation(66.6F, 0.0F, 0.8F, 0.0F, 0.2793F, 0.0F));
		PartDefinition Punta = partdefinition.addOrReplaceChild("Punta", CubeListBuilder.create().texOffs(0, 11).addBox(16.0F, 5.2F, 132.8336F, 8.0F, 7.1879F, 3.6664F, new CubeDeformation(0.0F)), PartPose.offset(-19.0F, 4.5F, -155.5F));
		PartDefinition bone18 = Punta.addOrReplaceChild("bone18", CubeListBuilder.create().texOffs(0, 13).addBox(8.0F, -14.111F, -3.6772F, 8.0F, 6.0F, 4.305F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.0F, 13.9426F, 134.2409F, -0.2618F, 0.0F, 0.0F));
		PartDefinition bone15 = Punta.addOrReplaceChild("bone15",
				CubeListBuilder.create().texOffs(39, 38).addBox(7.9281F, -1.6861F, -10.5F, -3.3F, -1.0014F, 0.7328F, new CubeDeformation(0.0F)).texOffs(39, 38).addBox(7.9281F, -0.6861F, -10.5F, -2.5F, -1.0014F, 0.7328F, new CubeDeformation(0.0F))
						.texOffs(39, 38).addBox(7.9281F, 0.3125F, -10.5F, -1.5F, -1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(39, 38).addBox(17.9281F, -1.2861F, -10.5F, -3.4F, -1.6014F, 2.7328F, new CubeDeformation(0.0F)).texOffs(39, 38)
						.addBox(17.2281F, -0.2861F, -10.5F, -2.1F, -1.0014F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 12).addBox(7.9281F, -3.6861F, -10.8F, 8.0F, 7.7986F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.0719F, 10.1861F, 138.4672F, -1.5708F, 0.0F, 0.0F));
		PartDefinition bone16 = Punta.addOrReplaceChild("bone16",
				CubeListBuilder.create().texOffs(39, 38).addBox(-16.8936F, -11.0F, -21.498F, 1.0F, 9.2F, -7.802F, new CubeDeformation(0.0F)).texOffs(39, 38).addBox(-16.8936F, -12.1F, -21.498F, 1.0F, 1.5F, -7.802F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.4F, 11.5F, 167.8F, 0.0F, -0.7854F, 0.0F));
		PartDefinition bone17 = Punta.addOrReplaceChild("bone17",
				CubeListBuilder.create().texOffs(39, 38).addBox(29.4482F, -10.0F, -5.5386F, 1.0F, 9.3F, -8.4614F, new CubeDeformation(0.0F)).texOffs(39, 38).addBox(29.4482F, -12.1F, -5.5386F, 1.0F, 2.5F, -8.4614F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(10.0F, 11.5F, 166.5F, 0.0F, 0.7854F, 0.0F));
		PartDefinition Flotador = partdefinition.addOrReplaceChild("Flotador",
				CubeListBuilder.create().texOffs(98, 54).addBox(-8.0F, -2.0F, 20.0F, 2.0F, 3.0F, -19.0F, new CubeDeformation(0.0F)).texOffs(115, 60).addBox(23.0F, -2.0F, 20.0F, 2.0F, 3.0F, -18.0F, new CubeDeformation(0.0F)).texOffs(92, 58)
						.addBox(-6.0F, 3.0F, 20.0F, 29.5F, 1.0F, -18.0F, new CubeDeformation(0.0F)).texOffs(80, 49).addBox(-5.0F, 3.0F, 2.0F, 26.9F, 1.0F, -5.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(-5.5F, 3.0F, 2.0F, 0.8F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(21.8F, 3.0F, 2.2F, 0.8F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(11.9F, 3.0F, -21.85F, 2.0F, 1.0F, -4.15F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(3.8F, 3.0F, -21.3F, 2.0F, 1.0F, -6.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(13.7F, 3.0F, -20.7F, 2.0F, 1.0F, -3.5F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(3.0F, 3.0F, -22.0F, 0.9F, 1.0F, -4.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(2.1F, 3.0F, -21.5F, 0.9F, 1.0F, -4.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(1.0F, 3.0F, -21.9F, 1.1F, 1.0F, -2.6F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(0.5F, 3.0F, -21.9F, 1.1F, 1.0F, -2.1F, new CubeDeformation(0.0F)).texOffs(84, 51).addBox(-3.0F, 3.0F, -3.0F, 23.2F, 1.0F, -5.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(-3.7F, 3.0F, -3.0F, 1.2F, 1.0F, -5.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(-2.4F, 3.0F, -8.0F, 1.2F, 1.0F, -5.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(-0.4F, 3.0F, -15.0F, 1.2F, 1.0F, -5.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(-1.2F, 3.0F, -15.0F, 1.2F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(16.8F, 3.0F, -15.0F, 1.2F, 1.0F, -2.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(-3.0F, 3.0F, -8.0F, 1.2F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(18.3F, 3.0F, -8.0F, 1.2F, 1.0F, -4.0F, new CubeDeformation(0.0F)).texOffs(20, 18).addBox(19.9F, 3.0F, -2.8F, 1.2F, 1.0F, -4.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(-4.3F, 3.0F, -3.0F, 1.2F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(88, 49).addBox(-1.8F, 3.0F, -8.0F, 20.3F, 1.0F, -7.0F, new CubeDeformation(0.0F)).texOffs(20, 18)
						.addBox(19.2F, 3.0F, -8.0F, 0.5F, 1.0F, -3.0F, new CubeDeformation(0.0F)).texOffs(0, 17).addBox(0.0F, 3.0F, -15.0F, 17.2F, 1.0F, -7.0F, new CubeDeformation(0.0F)).texOffs(8, 20)
						.addBox(5.0F, 3.0F, -21.2F, 8.0F, 1.0F, -8.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-8.0F, 16.0F, 8.0F));
		PartDefinition bone21 = Flotador.addOrReplaceChild("bone21", CubeListBuilder.create().texOffs(20, 18).addBox(-18.7657F, -2.0F, -21.1115F, 2.126F, 3.0F, -8.8885F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.8F, 0.0F, 4.0F, 0.0F, -0.7854F, 0.0F));
		PartDefinition bone29 = Flotador.addOrReplaceChild("bone29", CubeListBuilder.create().texOffs(20, 18).addBox(-20.5739F, -4.4253F, -21.7445F, 1.0F, 3.0F, -7.5555F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.5F, 1.8F, 6.3F, 0.1745F, -0.7854F, -0.2618F));
		PartDefinition bone20 = Flotador.addOrReplaceChild("bone20", CubeListBuilder.create().texOffs(126, 77).addBox(-7.4236F, -2.0F, 2.9946F, 2.0F, 3.0F, -26.0594F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -0.2618F, 0.0F));
		PartDefinition bone26 = bone20.addOrReplaceChild("bone26", CubeListBuilder.create().texOffs(127, 80).addBox(-3.3709F, 6.7085F, 0.9687F, 0.8014F, 3.5F, -26.0594F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-7.9206F, -6.5F, 2.1223F, 0.0F, 0.0F, -0.5236F));
		PartDefinition bone23 = Flotador.addOrReplaceChild("bone23", CubeListBuilder.create().texOffs(20, 18).addBox(27.564F, -2.0F, -7.947F, 2.242F, 3.0F, -8.053F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.8F, 0.0F, 3.0F, 0.0F, 0.7854F, 0.0F));
		PartDefinition bone28 = Flotador.addOrReplaceChild("bone28", CubeListBuilder.create().texOffs(20, 20).addBox(24.8F, -1.4F, -8.6875F, 2.3816F, 3.007F, -9.4125F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.2F, -0.6F, 3.1F, 0.0873F, 0.7854F, 0.1745F));
		PartDefinition bone25 = Flotador.addOrReplaceChild("bone25", CubeListBuilder.create().texOffs(114, 56).addBox(-22.4405F, -4.3825F, 21.0F, 1.0F, 3.5F, -18.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(41.3397F, 15.5F, -1.0F, 0.0F, 0.0F, 0.5236F));
		PartDefinition bone27 = Flotador.addOrReplaceChild("bone27", CubeListBuilder.create().texOffs(126, 79).addBox(-20.2374F, -5.0693F, -4.7135F, 1.0F, 3.5F, -25.6171F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(41.0397F, 13.5F, 2.0F, 0.0873F, 0.2618F, 0.4363F));
		PartDefinition bone22 = Flotador.addOrReplaceChild("bone22", CubeListBuilder.create().texOffs(127, 82).addBox(21.7072F, -2.0F, 8.3872F, 2.0F, 3.0F, -26.5073F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.2618F, 0.0F));
		PartDefinition bone24 = Flotador.addOrReplaceChild("bone24", CubeListBuilder.create().texOffs(122, 76).addBox(-4.1864F, 7.3139F, 21.0F, 1.0F, 3.5F, -19.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, -7.5F, -1.0F, 0.0F, 0.0F, -0.5236F));
		PartDefinition bone19 = Flotador.addOrReplaceChild("bone19", CubeListBuilder.create().texOffs(105, 33).addBox(55.0F, 0.0F, 21.0F, 3.0F, 33.0F, -1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, 56.0F, 0.0F, 0.0F, 0.0F, -1.5708F));
		PartDefinition Atrasyesquina = Flotador.addOrReplaceChild("Atrasyesquina", CubeListBuilder.create().texOffs(60, 79).addBox(4.15F, 8.2471F, 17.1327F, 31.0F, 3.0355F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-11.15F, -15.1399F, 9.3546F, -0.5236F, 0.0F, 0.0F));
		PartDefinition bone30 = Flotador.addOrReplaceChild("bone30", CubeListBuilder.create().texOffs(0, 15).addBox(8.0F, -8.511F, 9.1215F, 8.0F, 3.4184F, 2.9496F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, 11.4426F, -36.2591F, 0.3491F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}
