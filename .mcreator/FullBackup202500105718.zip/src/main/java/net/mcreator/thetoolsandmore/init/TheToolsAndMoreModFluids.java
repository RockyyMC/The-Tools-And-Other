
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thetoolsandmore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.thetoolsandmore.fluid.RedWaterFluid;
import net.mcreator.thetoolsandmore.fluid.GreenWaterFluid;
import net.mcreator.thetoolsandmore.TheToolsAndMoreMod;

public class TheToolsAndMoreModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, TheToolsAndMoreMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> GREEN_WATER = REGISTRY.register("green_water", () -> new GreenWaterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_GREEN_WATER = REGISTRY.register("flowing_green_water", () -> new GreenWaterFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> RED_WATER = REGISTRY.register("red_water", () -> new RedWaterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_RED_WATER = REGISTRY.register("flowing_red_water", () -> new RedWaterFluid.Flowing());

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(GREEN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_GREEN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(RED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_RED_WATER.get(), RenderType.translucent());
		}
	}
}
