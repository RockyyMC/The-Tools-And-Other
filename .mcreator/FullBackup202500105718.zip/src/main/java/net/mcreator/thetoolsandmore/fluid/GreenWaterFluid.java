
package net.mcreator.thetoolsandmore.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModItems;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModFluids;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModFluidTypes;
import net.mcreator.thetoolsandmore.init.TheToolsAndMoreModBlocks;

public abstract class GreenWaterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TheToolsAndMoreModFluidTypes.GREEN_WATER_TYPE.get(), () -> TheToolsAndMoreModFluids.GREEN_WATER.get(),
			() -> TheToolsAndMoreModFluids.FLOWING_GREEN_WATER.get()).explosionResistance(100f).tickRate(4).bucket(() -> TheToolsAndMoreModItems.GREEN_WATER_BUCKET.get()).block(() -> (LiquidBlock) TheToolsAndMoreModBlocks.GREEN_WATER.get());

	private GreenWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends GreenWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends GreenWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
