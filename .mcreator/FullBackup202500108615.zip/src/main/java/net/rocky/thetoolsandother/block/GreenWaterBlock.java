
package net.rocky.thetoolsandother.block;

import net.rocky.thetoolsandother.init.TheToolsAndOthesModFluids;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

public class GreenWaterBlock extends LiquidBlock {
	public GreenWaterBlock(BlockBehaviour.Properties properties) {
		super(TheToolsAndOthesModFluids.GREEN_WATER.get(), properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}
